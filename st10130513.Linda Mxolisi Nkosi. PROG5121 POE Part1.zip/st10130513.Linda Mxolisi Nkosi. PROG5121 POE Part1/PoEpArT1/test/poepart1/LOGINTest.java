package poepart1;


import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LOGINTest {

    private LOGIN login;

    @BeforeEach
    void setUp() {
        login = new LOGIN();
        // Set test data in PoEpArT1  for login tests
        PoEpArT1.setUserName("ab_cd");
        PoEpArT1.setPassword("Abc123!@");
    }

    // 🔹 checkUserName tests
    @Test
    void testValidUserName() {
        assertTrue(login.checkUserName("ab_cd"));
    }

    @Test
    void testInvalidUserNameTooLong() {
        assertFalse(login.checkUserName("abcdef"));
    }

    @Test
    void testInvalidUserNameNoUnderscore() {
        assertFalse(login.checkUserName("abcd"));
    }

    // 🔹 checkPasswordComplexity tests
    @Test
    void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Abc123!@"));
    }

    @Test
    void testPasswordTooShort() {
        assertFalse(login.checkPasswordComplexity("Ab1!"));
    }

    @Test
    void testPasswordNoCapitalLetter() {
        assertFalse(login.checkPasswordComplexity("abc123!@"));
    }

    @Test
    void testPasswordNoNumber() {
        assertFalse(login.checkPasswordComplexity("Abcdef!@"));
    }

    @Test
    void testPasswordNoSpecialCharacter() {
        assertFalse(login.checkPasswordComplexity("Abcdef12"));
    }

    // 🔹 checkPhoneNumber tests
    @Test
    void testValidPhoneNumber() {
        assertTrue(login.checkPhoneNumber("0831234567"));
    }

    @Test
    void testPhoneNumberTooShort() {
        assertFalse(login.checkPhoneNumber("08312345"));
    }

    @Test
    void testPhoneNumberDoesNotStartWithZero() {
        assertFalse(login.checkPhoneNumber("1831234567"));
    }

    // 🔹 registerUser tests
    @Test
    void testRegisterUserMessages() {
        String result = ogin.registerUser("ab_cd", "Abc123!@", "0831234567");
        assertTrue(result.contains("Password successfully captured"));
        assertTrue(result.contains("Username successfully captured"));
        assertTrue(result.contains("Phone number successfully captured"));
    }

    // 🔹 LoginUser (logic) tests
    @Test
    void testLoginUserSuccess() {
        assertTrue(login.LoginUser("ab_cd", "Abc123!@"));
    }

    @Test
    void testLoginUserWrongPassword() {
        assertFalse(login.LoginUser("ab_cd", "wrongPass"));
    }

    @Test
    void testLoginUserWrongUsername() {
        assertFalse(login.LoginUser("wrongUser", "Abc123!@"));
    }

    // 🔹 returnLoginStatus tests
    @Test
    void testReturnLoginStatusSuccess() {
        String msg = login.returnLoginStatus(true, "John", "Doe");
        assertEquals("Welcome John Doe, it is great to see you again!", msg);
    }

    @Test
    void testReturnLoginStatusFailure() {
        String msg = login.returnLoginStatus(false, "John", "Doe");
        assertEquals("Username or password incorrect, please try again", msg);
    }
}