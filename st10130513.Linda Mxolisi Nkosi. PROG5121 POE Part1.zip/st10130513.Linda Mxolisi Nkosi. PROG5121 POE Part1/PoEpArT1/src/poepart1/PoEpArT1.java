
package poepart1;
import java.util.Scanner;
public class PoEpArT1 
{
    private static String UserName;
    private static String PassWord;
    private static String Firstname;
    private static String Lastname;
    private static String PhoneNumber;
    

    
    public static void setUserName(String username){               
        UserName = username;
    }
    public static String getUserName(){
        return UserName;
    }
    
    public static void setPhoneNumber(String phonenumber){               
        PhoneNumber = phonenumber;
    }
    public static String getPhoneNumber(){
        return PhoneNumber;
    }
    
    public static void setPassword(String password){
        PassWord = password;
    }
    public static String getPassword(){
        return PassWord;
    }
    
    public static void setFirstname(String firstname){
        Firstname = firstname;
    }
    public static String getFirstname(){
        return Firstname;
    }
    
    
    public static void setLastname(String lastname){
        Lastname = lastname;
    }
    public static String getLastname(){
        return Lastname;
    }
    

    public static void main(String[] args)
    {
    
        LOGIN MyLogin = new LOGIN();
                       
        
        Scanner input = new Scanner(System.in);
        System.out.println(" *** REGISTRATION *** ");
        
        System.out.print("Please enter your Firstname: ");
        setFirstname(input.nextLine());
        
        System.out.print("Please enter your Lastname: ");
        setLastname(input.nextLine());
        System.out.print("Please enter your PhoneNumber:" + " " + "+27" );
        setPhoneNumber(input.nextLine());
        
        System.out.print("Please enter your username: ");
        setUserName(input.nextLine());
        
        MyLogin.checkUserName(getUserName()); 
        
        System.out.print("Please enter your PhoneNumber:" + " " + "+27" );
        setPhoneNumber(input.nextLine());
        
        
        
        
       
        System.out.print("Please enter the password: ");
        setPassword(input.nextLine());                

        MyLogin.checkPasswordComplexity(PassWord); 
        
        
        
        System.out.println(MyLogin.registerUser( getPassword(), getUserName(), (getPhoneNumber()));
        
        
        boolean regStatus = MyLogin.loginUser(MyLogin.checkUserName(getUserName()) ,MyLogin.checkPasswordComplexity(getPassword()), getPassword(), getUserName()), MyLogin.checkPhoneNumber(getPhoneNumber());
        
        System.out.println(MyLogin.returnLoginStatus(regStatus, getFirstname(), getLastname(),getPhoneNumber());
    
    }
    
}
